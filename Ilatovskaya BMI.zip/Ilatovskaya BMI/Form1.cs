﻿using System; // Иалтовская Устинья 22ИС-21
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ilatovskaya_BMI
{
    public partial class Form1 : Form {
        float index;
        float h;
        float w; 
    
 
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            h = float.Parse(height.Text);
            w = float.Parse(weight.Text);
            h = h / 100;
            index = w / (h * h);
            textBox1.Text = index.ToString();
            if (index < 18.5)
            {
                index = 5;
                textBox1.Text = "недостаточный";
            }
            else if (index >= 18.5 && index <= 24.9)
            {
                index = 15;
                textBox1.Text = "здоровый";
            }
            else if (index >= 25 && index <= 24.9)
            {
                index = 25;
                textBox1.Text = "избыточный";
            }
            else
            {
                index = 35;
                textBox1.Text = "ожирение";

            }
            trackBar1.Value = Convert.ToInt32(index);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            pictureBox3.Image = Properties.Resources.male_icon;
        }

        private void woman_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Properties.Resources.female_icon;
        }

    }
}
