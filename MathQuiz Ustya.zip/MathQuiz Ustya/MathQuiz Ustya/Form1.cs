﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Header;

namespace MathQuiz_Ustya
{
    public partial class Form1 : Form
    {

        // Создайте случайный объект с именем randomizer
        // для генерации случайных чисел.
        Random randomizer = new Random();

        // Эти целочисленные переменные хранят числа 
        // для задачи сложения.
        int addend1;
        int addend2;

        // Эти целочисленные переменные хранят числа 
        // для задачи вычитания.
        int minuend;
        int subtrahend;

        // These integer variables store the numbers 
        // for the multiplication problem. 
        int multiplicand;
        int multiplier;

        // Эти целочисленные переменные хранят числа 
        // для задачи умножения.
        int dividend;
        int divisor;

        // Эта целочисленная переменная отслеживает
        // оставшееся время.
        int timeLeft;

        /// <summary>
        /// Начните тест с заполнения всех заданий
        /// и запускаем таймер.
        /// </summary>
        public void StartTheQuiz()
        {
            // Заполните задачу сложения.
            // Сгенерируйте два случайных числа для добавления.
            // Сохраните значения в переменных 'addend1' и 'addend2'.
            addend1 = randomizer.Next(51);
            addend2 = randomizer.Next(51);

            // Преобразуйте два случайно сгенерированных числа
            // в строки, чтобы их можно было отображать
            // в элементах управления меткой.
            plusLeftLabel.Text = addend1.ToString();
            plusRightLabel.Text = addend2.ToString();

            // 'sum' - это имя элемента управления NumericUpDown.
            // На этом шаге убедитесь, что его значение равно нулю, прежде  чем 
            // добавлять к нему какие-либо значения.
            sum.Value = 0;

            // Заполните задачу на вычитание.
            minuend = randomizer.Next(1, 101);
            subtrahend = randomizer.Next(1, minuend);
            minusLeftLabel.Text = minuend.ToString();
            minusRightLabel.Text = subtrahend.ToString();
            difference.Value = 0;

            // Заполните задачу на умножение.
            multiplicand = randomizer.Next(2, 11);
            multiplier = randomizer.Next(2, 11);
            timesLeftLabel.Text = multiplicand.ToString();
            timesRightLabel.Text = multiplier.ToString();
            product.Value = 0;

            // Заполните задачу о делении.
            divisor = randomizer.Next(2, 11);
            int temporaryQuotient = randomizer.Next(2, 11);
            dividend = divisor * temporaryQuotient;
            dividedLeftLabel.Text = dividend.ToString();
            dividedRightLabel.Text = divisor.ToString();
            quotient.Value = 0;

            // Запустите таймер.
            timeLeft = 30;
            timeLabel.Text = "30 секунд";
            timer1.Start();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void startButton_Click(object sender, EventArgs e)
        {
            StartTheQuiz();
            startButton.Enabled = false;
        }

        private bool CheckTheAnswer()
        {
            if ((addend1 + addend2 == sum.Value)
                && (minuend - subtrahend == difference.Value)
                && (multiplicand * multiplier == product.Value)
                && (dividend / divisor == quotient.Value))
                return true;
            else
                return false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (CheckTheAnswer())
            {
                // // Если проверка ответа() возвращает значение true, то пользователь
                // получил правильный ответ. Остановите таймер  
                // и отобразить окно сообщений.
                timer1.Stop();
                MessageBox.Show("Ты правильно ответил на все вопросы!",
                                "Поздравляю!");
                startButton.Enabled = true;
            }
            else if (timeLeft > 0)
            {
                // // Если проверка ответа() возвращает значение false, продолжайте подсчет
                // вниз. Уменьшите оставшееся время на одну секунду и
                // отобразите новое оставшееся время, обновив метку
                // Оставшееся время.
                timeLeft = timeLeft - 1;
                timeLabel.Text = timeLeft + " секунд";
            }
            else
            {
                // Если у пользователя закончилось время, остановите таймер, покажите
                // // окно сообщения и заполните ответы.
                timer1.Stop();
                timeLabel.Text = "Время вышло!";
                MessageBox.Show("Вы не закончили вовремя", "Извините!");
                sum.Value = addend1 + addend2;
                difference.Value = minuend - subtrahend;
                product.Value = multiplicand * multiplier;
                quotient.Value = dividend / divisor;
                startButton.Enabled = true;
            }
            if (timeLeft <= 5)
            {
                timeLabel.BackColor = Color.Red;
            }
            else if (timeLeft <= 30)
            {
                timeLabel.BackColor = Color.Green;
            }
        }
        private void answer_Enter(object sender, EventArgs e)
        {
            // Выберите весь ответ в элементе управления NumericUpDown.
            NumericUpDown answerBox = sender as NumericUpDown;

            if (answerBox != null)
            {
                int lengthOfAnswer = answerBox.Value.ToString().Length;
                answerBox.Select(0, lengthOfAnswer);
            }
        }

        private void timeLabel_Click(object sender, EventArgs e)
        {

        }

        private void начатьЗановоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StartTheQuiz();
            startButton.Enabled = false;
        }
    }
}
