﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; // 10 вариант Илатовская Устинья 22 ИС-21

namespace ila_consol_1
    // Вывести результат точного соответствия Equals для sin(3.14) и sin(пи). Обосновать его дополнительным выводом результатов расчета обеих указанных функций sin.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a = Math.Sin(3.14);
            double b = Math.Sin(Math.PI);
            Console.WriteLine(a.Equals(b));//true
            Console.WriteLine(a);
            Console.WriteLine(b);
            {
                Console.ReadLine();
            }
        }
    }

}

