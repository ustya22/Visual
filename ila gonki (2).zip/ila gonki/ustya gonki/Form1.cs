﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ustya_gonki
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void clear()
        {
            pictureBoxDrinks.Visible = false; labelDrinks.Visible = false;
            pictureBoxEnergy.Visible = false; labelEnergy.Visible = false;
            pictureBoxTuilets.Visible = false; labelToilets.Visible = false;
            pictureBoxInformation.Visible = false; labelInformation.Visible = false;
            pictureBoxMedical.Visible = false; labelMedical.Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            NameLabel.Text = "ФИНИШ!";
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Старт гонки 1";
            GonkiLabel.Text = "Самбо полный марафон";
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "МЦК Лужники";
            pictureBoxEnergy.Visible = true; labelDrinks.Visible = true;
            pictureBoxDrinks.Visible = true; labelEnergy.Visible = true;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Новодевичей монастырь";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Метро Киевская";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "МИД";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
           
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Старт гонки 2";
            GonkiLabel.Text = "Джонго полумарафон";
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Парк Горького";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Здание РАН";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Метро Воробьевы горы";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Старт гонки 3";
            GonkiLabel.Text = "Капоэйра веселый забег на 5 км";
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Стадион Лужники";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
