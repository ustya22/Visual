﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Drawing.Printing;

namespace textEdit_Ilatovskaya
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK) //Проверяем был ли выбран файл
            {
                richTextBox.Clear(); //Очищаем richTextBox
                openFileDialog.Filter = "Text Files (*.txt)|*.txt"; //Указываем что нас интересуют
                //только текстовые файлы
                string fileName = openFileDialog.FileName; //получаем наименование файл и путь к
                                                           // нему.
                richTextBox.Text = File.ReadAllText(fileName, Encoding.GetEncoding(1251)); //Передаем
                                                                                           //содержимое файла в richTextBox
            }

        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text Files|*.txt";//Задаем доступные расширения
            saveFileDialog1.DefaultExt = ".txt"; //Задаем расширение по умолчанию
            //3
            if (saveFileDialog1.ShowDialog() == DialogResult.OK) //Проверяем подтверждение
                                                                 //сохранения информации.
            {
                var name = saveFileDialog1.FileName; //Задаем имя файлу
                File.WriteAllText(name, richTextBox.Text, Encoding.GetEncoding(1251)); //Записываем
                                                                                       //в файл содержимое textBox с кодировкой 1251
            }
            richTextBox.Clear();
        }

        private void поЦентруToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Select(); // выравнивание только выделенного текста
                                  //richTextBox1.SelectAll(); //выделение всего текста
            richTextBox.SelectionAlignment = HorizontalAlignment.Center;
            //richTextBox1.DeselectAll(); //Отмена выделения

        }

        private void поПравойСторонеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Select(); // выравнивание только выделенного текста
                                  //richTextBox1.SelectAll(); //выделение всего текста
            richTextBox.SelectionAlignment = HorizontalAlignment.Right;
            //richTextBox1.DeselectAll(); //Отмена выделения

        }

        private void поЛевойСторонеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Select(); // выравнивание только выделенного текста
                                  //richTextBox1.SelectAll(); //выделение всего текста
            richTextBox.SelectionAlignment = HorizontalAlignment.Left;
            //richTextBox1.DeselectAll(); //Отмена выделения

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font myFont = new Font("Tahoma", 12, FontStyle.Regular, GraphicsUnit.Pixel);
            string Hello = "Hello World!";
            e.Graphics.DrawString(Hello, myFont, Brushes.Black, 20, 20);
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
        }

        private void вставитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Определяем, есть ли текст в буфере обмена для вставки в текстовое поле.
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                // Определяем, выделен ли какой-либо текст в текстовом поле.
                if (richTextBox.SelectionLength > 0)
                {
                    // Спрашиваем пользователя, хотят ли они вставить текущий выделенный текст.
                    if (MessageBox.Show("Do you want to paste over current selection?", "Cut Example", MessageBoxButtons.YesNo) == DialogResult.No)
                        // Переместить выделение в точку после текущего выделения и вставить.
                        richTextBox.SelectionStart = richTextBox.SelectionStart + richTextBox.SelectionLength;
                }
                // Вставить текущий текст из буфера обмена в текстовое поле.
                richTextBox.Paste();
            }
        }

        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {

            // Убедитесь, что текст выделен в текстовом поле.   
            if (richTextBox.SelectionLength > 0)
                // Копируем выделенный текст в буфер обмена.
                richTextBox.Copy();

        }

        private void вырезатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Убедитесь, что текст в данный момент выделен в текстовом поле.
            if (richTextBox.SelectedText != "")
                // Вырезать выделенный текст в элементе управления и вставить его в буфер обмена.
                richTextBox.Cut();
        }

        private void настройкаПринтераToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pageSetupDialog.ShowDialog();
        }

        private void предварительныйПросмотрToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialog.ShowDialog();
        }

        private void печатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (printDialog.ShowDialog() == DialogResult.OK) printDocument.Print();
        }

        private void оПрограммеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AboutBox1 form = new AboutBox1();
            form.Show();
            this.Hide();
        }

        private void cutButton_Click(object sender, EventArgs e)
        {
            // Убедитесь, что текст в данный момент выделен в текстовом поле. 
            if (richTextBox.SelectedText != "")
                // Вырезать выделенный текст в элементе управления и вставить его в буфер обмена.
                richTextBox.Cut();
        }

        private void copyButton_Click(object sender, EventArgs e)
        {
            // Убедитесь, что текст выделен в текстовом поле.
            if (richTextBox.SelectionLength > 0)
                // Копируем выделенный текст в буфер обмена.
                richTextBox.Copy();
        }

        private void pasteButton_Click(object sender, EventArgs e)
        {
            // Определяем, есть ли текст в буфере обмена для вставки в текстовое поле.
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                // Определяем, выделен ли какой-либо текст в текстовом поле.
                if (richTextBox.SelectionLength > 0)
                {
                    // Спрашиваем пользователя, хотят ли они вставить текущий выделенный текст.
                    if (MessageBox.Show("Do you want to paste over current selection?", "Cut Example", MessageBoxButtons.YesNo) == DialogResult.No)
                        // Переместить выделение в точку после текущего выделения и вставить.
                        richTextBox.SelectionStart = richTextBox.SelectionStart + richTextBox.SelectionLength;
                }
                // Вставить текущий текст из буфера обмена в текстовое поле.
                richTextBox.Paste();
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
        }

        private void HighliteButton_Click(object sender, EventArgs e)
        {
            richTextBox.SelectionStart = 0;
            richTextBox.SelectAll();
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK) //Проверяем был ли выбран файл
            {
                richTextBox.Clear(); //Очищаем richTextBox
                openFileDialog.Filter = "Text Files (*.txt)|*.txt"; //Указываем что нас интересуют
                //только текстовые файлы
                string fileName = openFileDialog.FileName; //получаем наименование файл и путь к
                                                           // нему.
                richTextBox.Text = File.ReadAllText(fileName, Encoding.GetEncoding(1251)); //Передаем
                                                                                           //содержимое файла в richTextBox
            }

        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Закрыть форму.
            this.Close();
        }

        private void fontButton_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowColor = true;

            fontDialog1.Font = richTextBox.Font;
            fontDialog1.Color = richTextBox.ForeColor;

            if (fontDialog1.ShowDialog() != DialogResult.Cancel)
            {
                richTextBox.Font = fontDialog1.Font;
                richTextBox.ForeColor = fontDialog1.Color;
            }
        }

        private void colorButton_Click(object sender, EventArgs e)
        {
            ColorDialog MyDialog = new ColorDialog();
            // Запрещает пользователю выбирать собственный цвет.
            MyDialog.AllowFullOpen = false;
            // Позволяет пользователю получить помощь. (По умолчанию — ложь.)
            MyDialog.ShowHelp = true;
            // Устанавливает начальный выбор цвета на текущий цвет текста.
            MyDialog.Color = richTextBox.ForeColor;

            // Обновляем цвет текстового поля, если пользователь нажимает OK
            if (MyDialog.ShowDialog() == DialogResult.OK)
                richTextBox.ForeColor = MyDialog.Color;
        }

        private void вырезатьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Убедитесь, что текст в данный момент выделен в текстовом поле. 
            if (richTextBox.SelectedText != "")
                // Вырезать выделенный текст в элементе управления и вставить его в буфер обмена.
                richTextBox.Cut();
        }

        private void копироватьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Убедитесь, что текст выделен в текстовом поле.   
            if (richTextBox.SelectionLength > 0)
                // Копируем выделенный текст в буфер обмена.
                richTextBox.Copy();
        }

        private void вставитьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Определяем, есть ли текст в буфере обмена для вставки в текстовое поле.
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                // Определяем, выделен ли какой-либо текст в текстовом поле.
                if (richTextBox.SelectionLength > 0)
                {
                    // Спрашиваем пользователя, хотят ли они вставить текущий выделенный текст.
                    if (MessageBox.Show("Do you want to paste over current selection?", "Cut Example", MessageBoxButtons.YesNo) == DialogResult.No)
                        // Переместить выделение в точку после текущего выделения и вставить.
                        richTextBox.SelectionStart = richTextBox.SelectionStart + richTextBox.SelectionLength;
                }
                // Вставить текущий текст из буфера обмена в текстовое поле.
                richTextBox.Paste();
            }
        }

        private void очиститьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
        }

        private void шрифтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowColor = true;

            fontDialog1.Font = richTextBox.Font;
            fontDialog1.Color = richTextBox.ForeColor;

            if (fontDialog1.ShowDialog() != DialogResult.Cancel)
            {
                richTextBox.Font = fontDialog1.Font;
                richTextBox.ForeColor = fontDialog1.Color;
            }
        }

        private void цветToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog MyDialog = new ColorDialog();
            // Запрещает пользователю выбирать собственный цвет.
            MyDialog.AllowFullOpen = false;
            // Позволяет пользователю получить помощь. (По умолчанию — ложь.)
            MyDialog.ShowHelp = true;
            // Устанавливает начальный выбор цвета на текущий цвет текста.
            MyDialog.Color = richTextBox.ForeColor;

            // Обновляем цвет текстового поля, если пользователь нажимает OK
            if (MyDialog.ShowDialog() == DialogResult.OK)
                richTextBox.ForeColor = MyDialog.Color;
        }
    }
}
